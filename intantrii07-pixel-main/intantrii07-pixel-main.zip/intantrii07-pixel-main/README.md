## 🌸 Halo, aku Intann 💗

🎒 Siswi SMA kelas 12  
💻 Sedang belajar coding  
🌱 Masih pemula tapi semangat belajar  
✨ Future developer in progress  

---

## 💖 Tentang Aku

Aku adalah pelajar yang sedang mencoba memahami dunia teknologi sedikit demi sedikit.  
Aku suka hal-hal aesthetic, warna pink, dan belajar hal baru 🌷  

---

## 💻 Yang Sedang Aku Pelajari

🌸 HTML  
🌸 CSS  
🌸 Dasar Web Development  

---

## ✨ Project-ku

🌷 Website sederhana (HTML)  
🌷 Tugas sekolah berbasis web  

---

## 💌 Kontak

📧 Email: intan.trii07@gmail.com
